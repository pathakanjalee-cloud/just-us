# Just Us — iPhone app project

This folder wraps the existing Just Us HTML/CSS/JavaScript app with Capacitor.

## What is included
- Existing Just Us web app in `www/`
- Capacitor iOS configuration
- Capacitor 8 dependencies
- Scripts for generating/syncing the iOS project

## Next build step
On a Mac/cloud Mac:

```bash
npm install
npx cap add ios
npx cap sync ios
npx cap open ios
```

Then configure the Apple Developer signing team and build with the current Xcode/iOS SDK.

The existing app continues to use its Supabase Realtime backend and the external Supabase/YouTube browser SDKs already present in `www/index.html`.
